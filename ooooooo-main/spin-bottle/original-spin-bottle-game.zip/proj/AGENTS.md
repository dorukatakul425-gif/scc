<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep the imported game on the index route and its visual rules in the shared stylesheet, preserving the uploaded game's presentation.
- Use a full-width wood surface with a centered, height-bounded inner seat layout so the table fills the screen without stretching player portraits or hiding chat.
- Import uploaded game media through asset pointer JSON files so original images are served without storing binary assets in the repository.
